﻿namespace BookStore.Models
{
    public class BookViewModel
    {
        public Book book { get; set; }
    }
}
