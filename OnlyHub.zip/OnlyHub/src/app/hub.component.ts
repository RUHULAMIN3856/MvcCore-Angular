import { Component, OnInit, EventEmitter } from '@angular/core';
import { HubConnection, HubConnectionBuilder,  } from "@aspnet/signalr";
import { Student } from './student.model';

@Component({
  selector: 'app-root',
  templateUrl: './hub.component.html'
})
export class HubComponent implements OnInit {

  signalRCon: HubConnection = null;
  mode:string= "No Action";
  students: Student[] = null;
  student:Student = new Student();
  message:EventEmitter<Student[]> =new EventEmitter<Student[]>();

  constructor() {
    this.signalRCon = new HubConnectionBuilder().withUrl("http://localhost:5000/Crud").build();

    this.signalRCon.start().then(value => {
      console.log("connected")
      this.signalRCon.invoke("GetStudents");
    }).catch(err => console.log(err));
  }

  ngOnInit(): void {
    this.signalRCon.on("students", (value:Student[]) => {
      this.message.emit(value);
  })

  this.signalRCon.on("student", (data:any)=>{
    if (data.error) {
      window.alert(data.error)
    }  else{
      this.message.emit(data)
    }
  });

  this.signalRCon.onclose((value)=>{
    window.alert(value);
  })

  this.message.subscribe((data:any)=>{
    debugger;
    if (data.inserted) {
      this.students.push(new Student(data.studentID,data.name,data.email,data.mobile));
      this.student = new Student();
      this.mode = "No Action";
    }else if (data.updated) {
      this.students.splice(this.students.findIndex(s=> s.studentID == Number.parseInt( data.studentID)),1, new Student(data.studentID,data.name,data.email,data.mobile))
      this.student = new Student();
      this.mode = "No Action";
    } else{
      this.students = [];
      data.forEach((s: Student)=> this.students.push(s));
    }
  })
}

  editStudent(value: string) {
    this.mode = "Update"
    let data = this.students.find(s=> s.studentID == Number.parseInt(value));
    this.student =new Student(data.studentID,data.name,data.email,data.mobile);
  }

  createStudent(mode:string){
    this.mode = mode;
    this.student = new Student();
  }

  saveStudent(){
    if (this.mode == "create") {
      this.signalRCon.invoke("InsertStudent",this.student);
    } else{
      this.signalRCon.invoke("UpdateStudent",this.student);
    }
  }

  deleteStudent(value:string){
    this.signalRCon.invoke("DeleteStudent",value);
  }

  clear(){
    this.student = new Student();
    this.mode = "No Action";
  }
}
