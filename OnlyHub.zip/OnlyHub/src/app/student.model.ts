
export class Student{
    constructor(public studentID?:number,
        public name?:string, 
        public email?:string, 
        public mobile?:string){
            
        }
}