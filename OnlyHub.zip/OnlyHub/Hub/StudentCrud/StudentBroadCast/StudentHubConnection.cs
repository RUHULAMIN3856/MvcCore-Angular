﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using StudentCrud.DBContexts;
using StudentCrud.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace StudentCrud.StudentBroadCast
{
    public class StudentCrudHub: Hub
    {
        private readonly StudentDBContext _db = null;
        public StudentCrudHub(StudentDBContext db)
        {
            this._db = db;
        }

        public void GetStudents()
        {
            Student[] students = this._db.Students.ToArray();
            Clients.All.SendAsync("students", students);
        }

        public void InsertStudent(Student student)
        {
           
            _db.Entry<Student>(student).State = Microsoft.EntityFrameworkCore.EntityState.Added;
            try
            {
                _db.SaveChanges();
                Student _student = this._db.Students.Where(s => s.StudentID == student.StudentID).FirstOrDefault();
                Clients.All.SendAsync("student", new {inserted=true, student.StudentID,student.Name,student.Email,student.Mobile });
            }
            catch (DbUpdateException ex)
            {
                Clients.All.SendAsync("student", new {error = $"{ex.InnerException.Message}" });
            }
            
        }


        public void DeleteStudent(int id)
        {
           Student _student =  _db.Students.Where(s => s.StudentID == id).FirstOrDefault();

            _db.Entry<Student>(_student).State = EntityState.Deleted;
            _db.SaveChanges();

            Student[] students = this._db.Students.ToArray();
            Clients.All.SendAsync("students", students);
        }

        public void UpdateStudent(Student student)
        {
            _db.Entry<Student>(student).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            try
            {
                _db.SaveChanges();
                Student _student = this._db.Students.Where(s => s.StudentID == student.StudentID).FirstOrDefault();
                Clients.All.SendAsync("student", new { updated = true, student.StudentID, student.Name, student.Email, student.Mobile });
            }
            catch (DbUpdateException ex)
            {
                Clients.All.SendAsync("student", new { error = $"{ex.InnerException.Message}" });
            }

        }
    }
}
