﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.EntityFrameworkCore;
using StudentCrud.DBContexts;
using StudentCrud.StudentBroadCast;

namespace StudentCrud
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
            services.AddSignalR();

            services.AddCors(option =>
            {
                option.AddPolicy("angular", builder =>
                {
                    builder.WithOrigins("http://localhost:4200").AllowAnyMethod().AllowAnyHeader().AllowCredentials();
                });
            });

            services.AddDbContext<StudentDBContext>(config =>
            {
                config.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
            });

           
        }

       
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
           

            app.UseCors("angular");

            app.UseSignalR(op =>
            {
                op.MapHub<StudentCrudHub>("/Crud");
                
            });

            app.UseMvcWithDefaultRoute();
        }
    }
}
