﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace StudentCrud.Controllers
{
    
    public class ValuesController : Controller
    {
        [Route("Home")]
        public async void GetIndex()
        {
             await Response.WriteAsync("<h1>Hub is runing</h1>");
        }
    }
}