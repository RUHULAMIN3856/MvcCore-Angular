﻿using Microsoft.EntityFrameworkCore;
using StudentCrud.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentCrud.DBContexts
{
    public class StudentDBContext: DbContext
    {
        public StudentDBContext(DbContextOptions<StudentDBContext> options): base(options)
        {

        }
        public DbSet<Student> Students { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>().HasData
                (
                new Student() { StudentID = 1243274, Name = "Md Kajal Shek", Email = "Kajalshekjual@gmail.com", Mobile = "01922166098" },
                new Student() { StudentID = 1243275, Name = "Md Rubel Shek", Email = "RubelHossain@gmail.com", Mobile = "01922166098" },
                new Student() { StudentID = 1243276, Name = "Md Saddam Hossain", Email = "Kajalshekjual@gmail.com", Mobile = "01922166098" }
                );
        }
    }
}
