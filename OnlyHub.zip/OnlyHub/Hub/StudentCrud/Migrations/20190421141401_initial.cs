﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace StudentCrud.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    StudentID = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    Mobile = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.StudentID);
                });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentID", "Email", "Mobile", "Name" },
                values: new object[] { 1243274, "Kajalshekjual@gmail.com", "01922166098", "Md Kajal Shek" });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentID", "Email", "Mobile", "Name" },
                values: new object[] { 1243275, "RubelHossain@gmail.com", "01922166098", "Md Rubel Shek" });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "StudentID", "Email", "Mobile", "Name" },
                values: new object[] { 1243276, "Kajalshekjual@gmail.com", "01922166098", "Md Saddam Hossain" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Students");
        }
    }
}
