﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BookShop.Migrations
{
    public partial class bookmana : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
