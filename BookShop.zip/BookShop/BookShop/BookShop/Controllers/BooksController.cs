﻿using BookShop.Data;
using BookShop.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace BookShop.Controllers
{
    public class BooksController : Controller
    {
        private readonly BookContext _context;

        public BooksController(BookContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            var books = _context.Books.ToList();

            var model = new BookListViewModel()
            {
                Books = books
            };

            return new JsonResult(model);
        }

        [HttpGet]
        public IActionResult Get (int? Id)
        {
            var _book = _context.Books.FirstOrDefault(b => b.BookId == Id);

            var model = new BookViewModel()
            {
                book = _book
            };

            return new JsonResult(model);
        }

        public IActionResult Delete(int? Id)
        {
            var _book = _context.Books.FirstOrDefault(b => b.BookId == Id);
            _context.Books.Remove(_book);
            _context.SaveChanges();

            var model = new BookListViewModel()
            {
                Books = _context.Books.ToList()
            };

            return new JsonResult(model);
        }

        [HttpPost]
        public IActionResult Create(Book _book)
        {
            _context.Books.Add(_book);
            _context.SaveChanges();

            var model = new BookViewModel()
            {
                book = _book
            };

            return new JsonResult(model);
        }

        [HttpPost]
        public IActionResult Update (Book _book)
        {
            var ubook = _context.Books.FirstOrDefault(b=>b.BookId == _book.BookId);
            ubook.Title = _book.Title;
            ubook.Author = _book.Author;
            ubook.IsAvailable = _book.IsAvailable;
            _context.SaveChanges();

            var model = new BookViewModel()
            {
                book = ubook
            };

            return new JsonResult(model);
        }
    }
}