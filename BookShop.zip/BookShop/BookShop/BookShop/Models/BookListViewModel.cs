﻿using System.Collections.Generic;

namespace BookShop.Models
{
    public class BookListViewModel
    {
        public List<Book> Books { get; set; }
    }
}
