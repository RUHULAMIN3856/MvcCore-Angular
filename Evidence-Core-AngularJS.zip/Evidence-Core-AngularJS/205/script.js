//Print some lines
//================
//document.write ("Hello World!");
//console.log ("A 'Hello World!' text printed");
//alert ('Alert message');



/*
//Print something into a <Div>
var str = prompt ("Write some text...", "Sample text");
console.log ("You wrote " + str + ".");


// Print a time series (namta) using for loop
var num = prompt ("Enter a number...", "10");
if(isNaN(parseInt(num)))
{
	alert("Not a valid number!");
	document.write ("<h1 style=\"color: #ff0000\">Not a valid number</h1>");
}
else
{
	document.write ("<h1>Time Series of " + num + "</h1><hr/>");
	for (var i = 1; i <= 10; i++)
		document.write (num + " x " + i + " = " + (num * i) + "<br/>");
}



*/
/*

//Class Declatration

class TimeSeries
{
	constructor (num)
	{
		if(isNaN(parseInt(num)))
         {
			  alert("Not a valid number!");
			document.write ("<h1 style=\"color: #ff0000\">Not a valid number</h1>"); 
        }
		else
			this.tsNum = num; 
	}
	createTimeSeries()
	{
		var num= this.tsNum;
		if (num > 0)
		{	
	    document.write ("<h1>Time Series of " + num + "</h1><hr/>");
	    for (var i = 1; i <= 10; i++)
		document.write (num + " x " + i + " = " + (num * i) + "<br/>");
	}
	else
	{
		 alert("Not a valid number!");
			document.write ("<h1 style=\"color: #ff0000\">Not a valid number</h1>"); 
	   }
   } 
}
var num = prompt ("Enter a number...", "10");
//create instant of a class
let timeSeries =new TimeSeries(num);
// Accessing instance method
timeSeries.createTimeSeries();
// Accessing instance method
document.write("<hr/>Number = " + timeSeries.tsNum);
*/


//inharitance

//superClass

class Person{
	_firstName ='';
	_lastNname ='';
	
constructor (fname, lname)
{
	this._firstName =fname;
	this._lastName =lname;
	alert('Valu recive same');
}
set firstName(value)
{
	this.fname=value;
get firstName (value)
{
	return this._firstName;
}
set lastName(value)
{
	this.lname=value;
get lastName (value)
{
	return this._lastName;
}
details()
{
	div.innerHTML += "<p> + this._firstName +" " this._lastName+"</p>";
    }
}
	
	//sub Class /Drived Class
	
class student extends person{
	
	constructor (fname, lastName, studentId){
		super (fname,lnam);
		this.studentId = studentId;
		alert('Recined student ID: ' studentId)
	
	
	
	
	
	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	