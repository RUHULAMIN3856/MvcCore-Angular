
//Print some lines
//================
//document.write ("Hello World!");
//console.log ("A 'Hello World!' text printed");
//alert ('Alert message');

/*
//Print something into a <Div>
var str = prompt ("Write some text...", "Sample text");
console.log ("You wrote " + str + ".");
*/

// Print a time series (namta) using for loop
/*
var num = prompt ("Enter a number...", "10");
if(isNaN(num))
{
	alert("Not a valid number!");
	document.write ("<h1 style=\"color: #ff0000\">Not a valid number</h1>");
}
else
{
	document.write ("<h1>Time Series of " + num + "</h1><hr/>");
	for (var i = 1; i <= 10; i++)
		document.write (num + " x " + i + " = " + (num * i) + "<br/>");
}
*/

/*
// Creating class
class TimeSeries
{
	tsNum = 0;
	
	constructor (num)
	{
		if(isNaN(num))
		{
			alert("Not a valid number!");
			document.write ("<h1 style=\"color: #ff0000\">Not a valid number</h1>");
		}
		else
			this.tsNum = num;
	}
	
	createTimeSeries()
	{
		var num = this.tsNum;
		if( num > 0)
		{
			document.write ("<h1>Time Series of " + num + "</h1><hr/>");
			for (var i = 1; i <= 10; i++)
				document.write (num + " x " + i + " = " + (num * i) + "<br/>");
		}	
	}
}

var num = prompt ("Enter a number...", "10");
// Creating instance of a class
let timeSeries = new TimeSeries(num);
// Accessing instance method
timeSeries.createTimeSeries();
// Accessing instance variable
document.write("<hr/>Number = " + timeSeries.tsNum);
*/

// Class inheritance
// Super class/ Base class
class Person {
	_firstName;
	_lastName;
	
	constructor(fname, lname) {
		this._firstName = fname;
		this._lastName = lname;
		alert ('Value received from Student.\n' + this._firstName + '\n' + this._lastName);
	}

	set firstName (value) {
		this.fname = value;
	}

	get firstName () {
		return this._firstName;
	}

	set lastName (value) {
		this.lname = value;
	}

	get lastName () {
		return this._lastName;
	}

	details() {		
		document.write ("<p>" + this._firstName + " " + this._lastName + "</p>");
	}
}

// Sub class/ Derived class
class Student extends Person {
	constructor(fname, lname, studentId) {
		super(fname, lname);
		this.studentId = studentId;
		alert('Received student ID: ' + studentId);
	}
	
	record() {
		super.details();
		document.write ("<p>Student ID: " + this.studentId + "</p>");
	}
}

let student = new Student ("Ruhul", "Amin", 1243837);
document.write ("<h1>Student</h1><hr/>");
student.record();



