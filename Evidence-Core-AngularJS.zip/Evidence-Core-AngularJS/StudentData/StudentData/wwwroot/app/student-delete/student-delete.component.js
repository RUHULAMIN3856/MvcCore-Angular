﻿'use strict';
// Register `studentDelete` component, along with its associated controller and template
angular.
    module('studentDelete').
    component('studentDelete', {
       
        controller: ['$http', '$routeParams', '$location',
            function StudentDeleteController($http, $routeParams, $location) {                
                
                $http.get('/Student/Delete/' + $routeParams.studentId).then(
                    function (response) {
                        //alert('Student ID, ' + $routeParams.studentId + ' deleted.');
                        self.students = response.data;
                        $location.path("/");
                    },

                    function (error) {
                        alert(JSON.stringify(error.data));
                    }
                );
            }
        ]
    });