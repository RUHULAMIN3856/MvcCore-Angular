/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 1000 [Id]
      ,[Address]
      ,[Batch]
      ,[Course]
      ,[Name]
      ,[Round]
      ,[Status]
  FROM [StudentData].[dbo].[Students]