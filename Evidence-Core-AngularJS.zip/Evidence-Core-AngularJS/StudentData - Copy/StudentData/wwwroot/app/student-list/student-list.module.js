// Define the `studentList` module
angular.module('studentList', []);