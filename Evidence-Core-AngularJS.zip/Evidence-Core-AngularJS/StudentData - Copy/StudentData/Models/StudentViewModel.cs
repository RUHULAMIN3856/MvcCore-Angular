﻿using System.Collections.Generic;

namespace StudentData.Models
{
    public class StudentViewModel
    {
        public Student Student { get; set; }
    }
}
